package controller;

public interface StudentsController {

    void deleteStudent();
}
