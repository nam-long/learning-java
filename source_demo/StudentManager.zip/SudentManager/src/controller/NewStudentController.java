package controller;

public interface NewStudentController {

    void newStudent();
}
